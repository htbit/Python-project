text = input('Введите слово или предложение: ')[::-1]
print(text) # 'OBRUT'